from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def home():
   return render_template('home.html')
@app.route('/l')
def login():
   return render_template('login.html')
@app.route('/signup')
def signup():
   return render_template('sign-up.html')
@app.route('/i')
def index():
   return render_template('index.html')
@app.route('/help')
def help():
   return render_template('help.html')

if __name__ == '__main__':
   app.run()